<?php

namespace Enqueue\Consumption\Exception;

class IllegalContextModificationException extends \LogicException implements ExceptionInterface
{
}
