<?php

namespace Enqueue\Consumption\Exception;

class LogicException extends \LogicException implements ExceptionInterface
{
}
