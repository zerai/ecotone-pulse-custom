<?php

namespace Enqueue\Consumption\Exception;

interface ExceptionInterface
{
}
