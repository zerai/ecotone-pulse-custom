<?php

namespace Ecotone\Modelling\Attribute;

#[\Attribute(\Attribute::TARGET_PROPERTY)]
class TargetAggregateVersion
{

}