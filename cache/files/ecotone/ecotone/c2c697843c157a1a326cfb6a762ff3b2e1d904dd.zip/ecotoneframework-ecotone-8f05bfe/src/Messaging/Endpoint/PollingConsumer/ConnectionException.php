<?php

namespace Ecotone\Messaging\Endpoint\PollingConsumer;

class ConnectionException extends \RuntimeException
{

}