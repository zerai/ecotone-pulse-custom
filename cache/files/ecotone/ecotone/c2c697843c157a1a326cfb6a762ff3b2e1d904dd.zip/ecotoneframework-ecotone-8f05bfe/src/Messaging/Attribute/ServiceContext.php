<?php

namespace Ecotone\Messaging\Attribute;

#[\Attribute(\Attribute::TARGET_METHOD)]
class ServiceContext
{

}