<?php
declare(strict_types=1);

namespace Ecotone\Messaging\Attribute;

#[\Attribute]
class AsynchronousRunningEndpoint
{
}