<?php


namespace Ecotone\Messaging\Attribute;

#[\Attribute(\Attribute::TARGET_PARAMETER)]
class ConsoleParameterOption
{}