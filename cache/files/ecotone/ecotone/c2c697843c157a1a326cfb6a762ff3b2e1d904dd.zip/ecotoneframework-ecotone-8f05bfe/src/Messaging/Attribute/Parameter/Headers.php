<?php declare(strict_types=1);

namespace Ecotone\Messaging\Attribute\Parameter;

#[\Attribute(\Attribute::TARGET_PARAMETER)]
class Headers
{
}