<?php

namespace Ecotone\Messaging\Attribute;

#[\Attribute]
final class PropagateHeaders
{

}