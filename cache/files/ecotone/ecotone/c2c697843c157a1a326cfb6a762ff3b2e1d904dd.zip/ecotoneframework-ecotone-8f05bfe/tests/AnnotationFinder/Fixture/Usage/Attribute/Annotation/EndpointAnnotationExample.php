<?php


namespace Test\Ecotone\AnnotationFinder\Fixture\Usage\Attribute\Annotation;

class EndpointAnnotationExample
{

}