<?php

namespace Test\Ecotone\AnnotationFinder\Fixture\Usage\Attribute\Annotation;

#[\Attribute]
class System
{

}