---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**Description**  
<!-- A clear and concise description of the new feature. -->

**Example**  
<!-- A simple example of the new feature (include PHP code, Annotation config, etc.)
     If it changes an existing feature, include a simple before/after comparison. -->
