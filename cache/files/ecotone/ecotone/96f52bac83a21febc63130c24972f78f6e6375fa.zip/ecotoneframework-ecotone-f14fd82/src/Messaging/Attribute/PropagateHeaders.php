<?php

namespace Ecotone\Messaging\Attribute;

use Attribute;

#[Attribute]
final class PropagateHeaders
{
}
