<?php

declare(strict_types=1);

namespace Ecotone\Messaging\Attribute;

use Attribute;

#[Attribute]
class AsynchronousRunningEndpoint
{
}
