<?php

namespace Ecotone\Messaging\Endpoint\PollingConsumer;

use RuntimeException;

class ConnectionException extends RuntimeException
{
}
