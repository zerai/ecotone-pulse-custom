<?php

namespace Ecotone\Messaging\Config\Annotation\ModuleConfiguration;

interface CoreModule
{
    public const NAME = 'core';
}
