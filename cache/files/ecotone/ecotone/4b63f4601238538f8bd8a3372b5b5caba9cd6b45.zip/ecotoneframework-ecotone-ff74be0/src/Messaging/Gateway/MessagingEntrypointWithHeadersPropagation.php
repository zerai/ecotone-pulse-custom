<?php

namespace Ecotone\Messaging\Gateway;

interface MessagingEntrypointWithHeadersPropagation extends MessagingEntrypoint
{
}
