<?php

namespace Ecotone\Messaging\Attribute;

use Attribute;

#[Attribute(Attribute::TARGET_PARAMETER)]
class ConsoleParameterOption
{
}
