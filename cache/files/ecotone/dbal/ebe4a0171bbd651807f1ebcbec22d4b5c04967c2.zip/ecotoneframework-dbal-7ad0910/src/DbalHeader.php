<?php

namespace Ecotone\Dbal;

interface DbalHeader
{
    public const HEADER_ACKNOWLEDGE = 'dbal_acknowledge';
}
