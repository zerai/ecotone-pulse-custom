<?php

namespace Ecotone\Dbal\Configuration;

interface DbalModule
{
    public const NAME = 'dbal';
}
