## Integration Messaging Symfony

[![Build Status](https://travis-ci.org/ecotoneframework/symfony.svg?branch=master)](https://travis-ci.org/ecotoneframework/symfony)
[![License](https://poser.pugx.org/ecotone/symfony/license)](https://packagist.org/packages/ecotone/symfony)
[![Latest Stable Version](https://poser.pugx.org/ecotone/symfony/v/stable)](https://packagist.org/packages/ecotone/symfony)

Provides integration for Symfony with [Ecotone](https://github.com/ecotoneframework/ecotone).
