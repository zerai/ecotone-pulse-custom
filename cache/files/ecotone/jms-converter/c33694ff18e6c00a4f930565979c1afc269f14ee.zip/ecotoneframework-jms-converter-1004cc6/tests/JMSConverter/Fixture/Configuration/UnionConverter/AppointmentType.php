<?php

namespace Test\Ecotone\JMSConverter\Fixture\Configuration\UnionConverter;

interface AppointmentType
{
    public function getType() : string;
}