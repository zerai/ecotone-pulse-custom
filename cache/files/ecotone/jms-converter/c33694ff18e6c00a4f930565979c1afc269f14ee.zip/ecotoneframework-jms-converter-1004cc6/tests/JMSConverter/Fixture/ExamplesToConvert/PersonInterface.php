<?php


namespace Test\Ecotone\JMSConverter\Fixture\ExamplesToConvert;


interface PersonInterface
{
    public function getName() : void;
}