<?php


namespace Test\Ecotone\JMSConverter\Fixture\ExamplesToConvert;


abstract class PersonAbstractClass
{
    public function getName() : void
    {

    }
}