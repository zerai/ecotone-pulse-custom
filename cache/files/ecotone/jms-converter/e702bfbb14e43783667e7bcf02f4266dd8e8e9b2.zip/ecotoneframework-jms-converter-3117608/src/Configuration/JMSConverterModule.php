<?php

namespace Ecotone\JMSConverter\Configuration;

interface JMSConverterModule
{
    public const NAME = 'jmsConverter';
}
