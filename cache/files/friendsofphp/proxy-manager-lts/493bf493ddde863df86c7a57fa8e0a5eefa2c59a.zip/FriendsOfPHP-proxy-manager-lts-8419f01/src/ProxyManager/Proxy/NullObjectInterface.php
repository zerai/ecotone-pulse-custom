<?php

declare(strict_types=1);

namespace ProxyManager\Proxy;

/**
 * Null object marker
 */
interface NullObjectInterface extends ProxyInterface
{
}
