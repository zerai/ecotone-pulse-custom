<?php
declare(strict_types=1);

namespace Interop\Amqp;

use Interop\Queue\SubscriptionConsumer;

interface AmqpSubscriptionConsumer extends SubscriptionConsumer
{
}
