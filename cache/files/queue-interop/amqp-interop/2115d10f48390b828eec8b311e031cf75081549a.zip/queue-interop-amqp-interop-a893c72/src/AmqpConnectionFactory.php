<?php
declare(strict_types=1);

namespace Interop\Amqp;

use Interop\Queue\ConnectionFactory;

interface AmqpConnectionFactory extends ConnectionFactory
{
}
