<?php
declare(strict_types=1);

namespace Interop\Queue;

interface Exception extends \Throwable
{
}
