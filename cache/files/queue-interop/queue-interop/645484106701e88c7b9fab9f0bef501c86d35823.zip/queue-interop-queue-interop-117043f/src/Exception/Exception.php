<?php
declare(strict_types=1);

namespace Interop\Queue\Exception;

class Exception extends \Exception implements \Interop\Queue\Exception
{
}